﻿namespace Ellisys.Injection;

public static class ObjectId
{
	public const byte DateTimeMs	= 0x01;
	public const byte DateTimeNs	= 0x02;
	public const byte GroupStart	= 0x04;
	public const byte GroupEnd		= 0x05;
	public const byte Text			= 0x06;
}
