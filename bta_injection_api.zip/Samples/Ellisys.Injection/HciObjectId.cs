﻿namespace Ellisys.Injection;

public static class HciObjectId
{
	public const byte Bitrate		= 0x80;
	public const byte HciPacketType	= 0x81;
	public const byte HciPacketData	= 0x82;
}
