﻿using System.IO;

namespace Ellisys.Injection;

public readonly struct Segment
{
	public Segment Slice(int offset) => new(m_data, m_offset + offset, Length - offset);

	public static implicit operator Segment(byte[] data) => new(data);

	public Segment(byte[] data) : this(data, 0, data.Length) { }

	public Segment(byte[] data, int offset, int length)
	{
		m_data = data;
		m_offset = offset;
		Length = length;
	}

	public ref byte this[int index] => ref m_data[m_offset + index];

	public void Write(BinaryWriter writer)
	{
		if (Length == 0) return;
		writer.Write(m_data, m_offset, Length);
	}

	private readonly byte[] m_data;
	private readonly int m_offset;

	public readonly int Length;
}
