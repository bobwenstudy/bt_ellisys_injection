﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;

namespace Ellisys.Injection;

public static class EllisysInjectionUtil
{
	public static byte[] PrepareHciInjectionPacket(DateTime packetTime, float packetBitrate, byte packetType, in Segment packetData)
	{
		const ushort HciInjectionServiceId = 0x0002;
		const byte HciInjectionServiceVersion = 0x01;

		using var memoryStream = new MemoryStream();
		using var writer = new BinaryWriter(memoryStream, Encoding.UTF8, leaveOpen: true);

		WriteServiceId(writer, HciInjectionServiceId, HciInjectionServiceVersion);
		WriteDateTimeNs(writer, packetTime);
		WriteBitrate(writer, packetBitrate);
		WriteHciData(writer, packetType, packetData);

		writer.Flush();
		return memoryStream.ToArray();
	}

	public static void WriteServiceId(this BinaryWriter writer, ushort serviceId, byte serviceVersion)
	{
		writer.Write(serviceId);
		writer.Write(serviceVersion);
	}

	public static void WriteDateTimeNs(this BinaryWriter writer, DateTime date)
	{
		var nanoseconds = date.TimeOfDay.Ticks * 100;

		writer.Write(ObjectId.DateTimeNs);
		writer.Write((ushort) date.Year);
		writer.Write((byte) date.Month);
		writer.Write((byte) date.Day);
		writer.Write((uint) (nanoseconds & 0xFFFFFFFF));
		writer.Write((ushort) (nanoseconds >> 32 & 0xFFFF));
	}

	public static void WriteDateTimeMs(this BinaryWriter writer, DateTime date)
	{
		writer.Write(ObjectId.DateTimeMs);
		writer.Write((ushort) date.Year);
		writer.Write((byte) date.Month);
		writer.Write((byte) date.Day);
		writer.Write((uint) date.TimeOfDay.TotalMilliseconds);
	}

	public static void WriteText(this BinaryWriter writer, string text)
	{
		writer.Write(ObjectId.Text);
		writer.Write(Encoding.UTF8.GetBytes(text));
		writer.Write((byte) 0);
	}

	public static void WriteGroupStart(this BinaryWriter writer)
	{
		writer.Write(ObjectId.GroupStart);
	}

	public static void WriteGroupEnd(this BinaryWriter writer)
	{
		writer.Write(ObjectId.GroupEnd);
	}

	public static void WriteSeverity(this BinaryWriter writer, Severity severity)
	{
		if(severity != Severity.None)
		{
			writer.Write(UserLogObjectId.Severity);
			writer.Write((byte)severity);
		}
	}

	public static void WriteLogField(this BinaryWriter writer, string title)
	{
		WriteText(writer, title);
	}

	public static void WriteLogField(this BinaryWriter writer, string title, string description, Severity severity = Severity.None)
	{
		WriteSeverity(writer, severity);
		WriteText(writer, title);
		WriteText(writer, description);
	}

	public static void WriteBitrate(this BinaryWriter writer, float bitrate)
	{
		writer.Write(HciObjectId.Bitrate);
		writer.Write(bitrate);
	}

	public static void WriteHciData(this BinaryWriter writer, byte hciPacketType, in Segment hciData)
	{
		writer.Write(HciObjectId.HciPacketType);
		writer.Write(hciPacketType);

		writer.Write(HciObjectId.HciPacketData);
		hciData.Write(writer);
	}
}
