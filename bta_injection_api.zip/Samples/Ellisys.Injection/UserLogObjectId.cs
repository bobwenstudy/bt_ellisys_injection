﻿namespace Ellisys.Injection;

public static class UserLogObjectId
{
	public const byte Severity		= 0x80;
}
