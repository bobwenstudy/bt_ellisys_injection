﻿namespace Ellisys.Injection;

static class ObjectSize
{
	public const int DateTimeMs		= 9;
	public const int DateTimeNs		= 11;
	public const int GroupStart		= 1;
	public const int GroupEnd		= 1;
	public const int Severity		= 2;
}
