﻿namespace Ellisys.Injection;

public static class InjectedHciPacketType
{
	public const byte Command				= 0x01;
	public const byte AclFromHost			= 0x02;
	public const byte AclFromController		= 0x82;
	public const byte ScoFromHost			= 0x03;
	public const byte ScoFromController		= 0x83;
	public const byte Event					= 0x84;
}
