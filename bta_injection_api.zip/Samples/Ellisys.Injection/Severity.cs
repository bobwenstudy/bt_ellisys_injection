﻿namespace Ellisys.Injection;

public enum Severity
{
	None		= 0xFF,
	Information = 0x01,
	Warning		= 0x02,
	Error		= 0x03
}
