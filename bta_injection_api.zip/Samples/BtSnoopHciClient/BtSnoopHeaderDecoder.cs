﻿using System.IO;

namespace BtSnoopHciClient;

struct BtSnoopHeaderDecoder
{
	public BtSnoopDataLinkType DataLink => m_data.Length >= 16
		? ((BtSnoopDataLinkType)((((uint)m_data[15]) << 0 | ((uint)m_data[14]) << 8 | (((uint)m_data[13]) << 16) | (((uint)m_data[12]) << 24)) >> 0))
		: 0;

	private byte[] m_data;

	public bool Read(BinaryReader reader)
	{
		if (reader == null) return false;

		try
		{
			var content = reader.ReadBytes(16);
			if (content == null || content.Length < 16) return false;
			m_data = content;
		}
		catch(IOException)
		{
			return false;
		}

		return true;
	}
}
