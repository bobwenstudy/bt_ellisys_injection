﻿namespace BtSnoopHciClient;

enum BtSnoopH4PacketType : byte
{
	Command		= 0x01,
	Acl			= 0x02,
	Sco			= 0x03,
	Event		= 0x04,
}
