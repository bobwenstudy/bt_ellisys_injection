﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Ellisys.Injection;

namespace BtSnoopHciClient;

static class Program
{
	//
	// This sample uses the Ellisys live HCI injection API to push a pre-captured BtSnoop trace.
	// The only purpose of this sample is to show the use of the API and to facilitate integration
	// in a real application.
	//
	public static int Main(string[] args)
	{
		// TO BE CONFIGURED:
		const string ServerIpAddress = "127.0.0.1";  // Use 127.0.0.1 when running in local computer
		const int ServerInjectionPort = 24352;

		if (args == null || args.Length < 1)
		{
			Console.Error.WriteLine("Usage: BtSnoopHciClient <btsnoop trace file path>");
			return -1;
		}

		var endPoint = new IPEndPoint(IPAddress.Parse(ServerIpAddress), ServerInjectionPort);

		using var udpClient = new UdpClient(0);
		using var reader = new BinaryReader(File.Open(args[0], FileMode.Open));

		var header = new BtSnoopHeaderDecoder();
		header.Read(reader);

		var dataLinkType = header.DataLink;
		var startTime = DateTime.UtcNow;
		var refTimeUs = ulong.MaxValue;

		const float HciBitRate = 12000000;  // 12 Mbit/s (USB Full Speed)

		while (reader.PeekChar() != -1)
		{
			var record = new BtSnoopRecordDecoder();
			record.Read(reader);

			var timeUs = record.TimestampMicroseconds;
			if (refTimeUs == ulong.MaxValue) refTimeUs = timeUs;

			var relativeTimeUs = timeUs - refTimeUs;
			var packetTime = startTime + TimeSpan.FromTicks((long)relativeTimeUs / 10);

			Segment packetRawData = record.PacketData;
			var packetData = BtSnoopExtractHciData(dataLinkType, packetRawData);
			var packetType = BtSnoopExtractPacketType(dataLinkType, BtSnoopIsDirectionToHost(record.Flags), packetRawData);

			var injectionPacket = EllisysInjectionUtil.PrepareHciInjectionPacket(packetTime, HciBitRate, packetType, packetData);
			udpClient.Send(injectionPacket, injectionPacket.Length, endPoint);

			// throttle: if not doing so, receiver UDP buffer will be flooded and drop packets
			// usually data would not arrive faster than real time, so no throttling would be necessary
			Thread.Sleep(1);
		}

		return 0;
	}


	private static Segment BtSnoopExtractHciData(BtSnoopDataLinkType linkType, in Segment packetData)
	{
		switch(linkType)
		{
			case BtSnoopDataLinkType.H4:	return BtSnoopExtractH4HciData(packetData);
			default:						Debug.Fail("ERROR: Unsupported BtSnoop data link type. Only H4 is supported by this sample."); break;
		}

		return default;
	}

	private static Segment BtSnoopExtractH4HciData(in Segment packetData)
	{
		if (packetData.Length <= 1) return default;
		return packetData.Slice(1);
	}

	private static byte BtSnoopExtractPacketType(BtSnoopDataLinkType linkType, bool isLinkEntityDirectionIn, in Segment packetData)
	{
		return linkType switch
		{
			BtSnoopDataLinkType.H4 => BtSnoopGetInjectedPacketType(
				packetData.Length >= 1 ? (BtSnoopH4PacketType)packetData[0] : 0,
				isLinkEntityDirectionIn),

			_ => 0,
		};
	}

	private static byte BtSnoopGetInjectedPacketType(BtSnoopH4PacketType h4PacketType, bool isLinkEntityDirectionIn)
	{
		return h4PacketType switch
		{
			BtSnoopH4PacketType.Command => InjectedHciPacketType.Command,
			BtSnoopH4PacketType.Acl => isLinkEntityDirectionIn ? InjectedHciPacketType.AclFromController : InjectedHciPacketType.AclFromHost,
			BtSnoopH4PacketType.Sco => isLinkEntityDirectionIn ? InjectedHciPacketType.ScoFromController : InjectedHciPacketType.ScoFromHost,
			BtSnoopH4PacketType.Event => InjectedHciPacketType.Event,
			_ => 0,
		};
	}

	private static bool BtSnoopIsDirectionToHost(BtSnoopPacketFlags flags)
	{
		return (flags & BtSnoopPacketFlags.DirectionIsControllerToHost) != 0;
	}
}
