﻿using System;
using System.IO;

namespace BtSnoopHciClient;

struct BtSnoopRecordDecoder
{
	public byte[] PacketData { get; private set; }

	public uint IncludedLength => m_data.Length >= 8
		? (((uint)m_data[7]) << 0 | ((uint)m_data[6]) << 8 | ((uint)m_data[5]) << 16 | ((uint)m_data[4]) << 24)
		: 0;

	public ulong TimestampMicroseconds => m_data.Length >= 24
		? ((((ulong)m_data[23]) << 0) | (((ulong)m_data[22]) << 8) | (((ulong)m_data[21]) << 16) | (((ulong)m_data[20]) << 24) | (((ulong)m_data[19]) << 32) | (((ulong)m_data[18]) << 40) | (((ulong)m_data[17]) << 48) | (((ulong)m_data[16]) << 56))
		: 0;

	public BtSnoopPacketFlags Flags => m_data.Length >= 12
		? ((BtSnoopPacketFlags)((((uint)m_data[11]) << 0) | (((uint)m_data[10]) << 8) | (((uint)m_data[9]) << 16) | (((uint)m_data[8]) << 24)))
		: 0;

	private byte[] m_data;

	public bool Read(BinaryReader reader)
	{
		if (reader == null) return false;

		try
		{
			var data = reader.ReadBytes(24);
			if (data == null || data.Length < 24) return false;

			m_data = data;

			var includedLength = (int)Math.Min(IncludedLength, int.MaxValue);
			var packetData = reader.ReadBytes(includedLength);
			if (packetData == null || packetData.Length < includedLength) return false;

			PacketData = packetData;
		}
		catch(IOException)
		{
			return false;
		}

		return true;
	}
}
