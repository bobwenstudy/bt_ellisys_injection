﻿namespace BtSnoopHciClient;

enum BtSnoopDataLinkType : uint
{
	H1		= 1001,		// unframed: packet type encoded in flags field
	H4		= 1002,
	Bcsp	= 1003,
	H5		= 1004,
}
