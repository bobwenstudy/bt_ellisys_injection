﻿using System;

namespace BtSnoopHciClient;

[Flags]
enum BtSnoopPacketFlags : uint
{
	DirectionIsControllerToHost		= 1 << 00,	// unset means "Host to Controller"
	FrameIsCommandOrEvent			= 1 << 01,	// unset means "ACL Data"
}
