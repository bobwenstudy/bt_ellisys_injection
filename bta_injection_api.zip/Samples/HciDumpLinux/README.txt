Example usage of this command line tool:

	hcidump -t -R -r trace.btsnoop | hciremotelog 192.168.1.15

where the last IP corresponds to the host running the analyser software. The tool expects time-stamped, binary hcidump output format as input (the according hcidump options shall be used).

All necessary code is in "main.cpp" and a KDevelop project is provided as well. The "release" folder contains everything needed to compile the tool  using "make" (from shell) within that folder.
