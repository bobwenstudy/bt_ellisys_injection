#include <arpa/inet.h>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <netinet/in.h>
#include <string>
#include <sys/socket.h>
#include <vector>

using namespace std;

class SafeHandle
{
public:
  SafeHandle(int handle) { m_handle = handle; }  
  ~SafeHandle() { if(m_handle >= 0) close(m_handle); }  
  operator int() const { return m_handle; }  

private:  
  int m_handle;
};

struct Timestamp
{
    int Year;
    int Month;
    int Day;
    int Hour;
    int Minute;
    double Second;
};

enum HciPacketType
{
  PacketTypeCommand		= 0x01,
  PacketTypeAclData		= 0x02,
  PacketTypeScoData		= 0x03,
  PacketTypeEvent		= 0x04,

  PacketTypeFromController	= 0x80,
};

class HciDumpPacket
{
public:
  void Start(Timestamp timestamp, bool isFromHost)
  {
    m_timestamp = timestamp;
    m_isFromHost = isFromHost;    
    m_totalLength = 0;
    m_buffer.clear();
  }

  void Add(uint8_t datum)
  {
    m_buffer.push_back(datum);
  }

  HciPacketType GetPacketType()
  {
    return (HciPacketType)(m_buffer.size() >= 1 ? m_buffer[0] : 0);
  }
  
  Timestamp GetTimestamp()
  {
    return m_timestamp;
  }
  
  bool GetIsFromHost()
  {
    return m_isFromHost;
  }

  bool IsComplete()
  {
    int totalLength = GetTotalLength();
    return totalLength > 0 && m_buffer.size() >= totalLength;
  }
  
  int GetHciDataSize()
  {
    int totalLength = GetTotalLength();
    return totalLength > 0 ? totalLength - 1 : 0;    
  }

  const uint8_t *GetHciData() { return m_buffer.data() + 1; }  

private:
  Timestamp m_timestamp;
  bool m_isFromHost;
  vector<uint8_t> m_buffer;
  int m_totalLength;
  
  int GetTotalLength()
  {
    return m_totalLength > 0 ? m_totalLength : m_totalLength = ExtractTotalLength();
  }

  int ExtractTotalLength()
  {
    switch(GetPacketType())
    {
      case PacketTypeCommand:	return m_buffer.size() >= 4 ? 4 + m_buffer[3] : 0;

      case PacketTypeAclData:
      case PacketTypeScoData:	return m_buffer.size() >= 5 ? 5 + m_buffer[3] | m_buffer[4] << 8 : 0;

      case PacketTypeEvent:	return m_buffer.size() >= 3 ? 3 + m_buffer[2] : 0;
    }
    
    return 0;
  }
};

enum InjectionObjectId
{
  DateTimeNs	= 0x02,
};

enum HciInjectionObjectId
{
  ObjectIdBitrate	= 0x80,
  ObjectIdHciPacketType	= 0x81,
  ObjectIdHciPacketData	= 0x82,
};

class InjectionSink
{
public:
  InjectionSink(int udpSocketHandle, sockaddr_in remoteAddr) : m_udpSocketHandle(udpSocketHandle), m_remoteAddr(remoteAddr)
  {
    time_t t = time(NULL);
    tm *utc = gmtime(&t);
    m_utcShiftSeconds = difftime(mktime(utc), t);
    
    if(utc->tm_isdst)
    {
      m_utcShiftSeconds -= 3600;
    }
  }
  
  void Process(HciDumpPacket &dump)
  {
    if(!dump.IsComplete())
    {
      return;
    }
    
    m_buffer.clear();
    
    Add(HciInjectionServiceId);
    Add(HciInjectionServiceVersion);
    AddDateTimeNs(dump.GetTimestamp());
    AddBitrate();
    AddPacketType(dump.GetPacketType(), dump.GetIsFromHost());
    AddPacketData(dump.GetHciData(), dump.GetHciDataSize());
    
    size_t sent = sendto(m_udpSocketHandle, m_buffer.data(), m_buffer.size(), 0, (sockaddr*)&m_remoteAddr, sizeof(sockaddr_in));
    
    if(sent < m_buffer.size())
    {
      cerr << "Failed to send UDP datagram" << endl;
      exit(-4);
    }
  }

private: 
  static const uint16_t HciInjectionServiceId		= 0x0002;
  static const uint8_t HciInjectionServiceVersion	= 0x01;
  static uint8_t s_bitRateUsb2[4];

  int m_udpSocketHandle;
  sockaddr_in m_remoteAddr;
  vector<uint8_t> m_buffer;
  time_t m_utcShiftSeconds;
  
  void Add(uint8_t value)
  {
    m_buffer.push_back(value);
  }
  
  void Add(uint16_t value)
  {
    m_buffer.push_back((uint8_t)value);
    m_buffer.push_back((uint8_t)(value >> 8));
  }
  
  void Add(uint32_t value)
  {
    m_buffer.push_back((uint8_t)value);
    m_buffer.push_back((uint8_t)(value >> 8));
    m_buffer.push_back((uint8_t)(value >> 16));
    m_buffer.push_back((uint8_t)(value >> 24));
  }
  
  void Add(const uint8_t *const data, int count)
  {
    for(int i = 0; i < count; ++i)
    {
      Add(data[i]);
    }
  }
  
  void AddDateTimeNs(Timestamp timestamp)
  {    
    Add((uint8_t)DateTimeNs);
    Add((uint16_t)timestamp.Year);
    Add((uint8_t)timestamp.Month);
    Add((uint8_t)timestamp.Day);
    
    uint64_t nanoseconds =
      (uint64_t)timestamp.Hour * 3600000000000LL +
      (uint64_t)timestamp.Minute * 60000000000LL +
      (int64_t)((timestamp.Second + m_utcShiftSeconds) * 1e9);
    
    Add((uint32_t)nanoseconds);
    Add((uint16_t)(nanoseconds >> 32));
  }
  
  void AddBitrate()
  {
    Add((uint8_t)ObjectIdBitrate);
    Add(s_bitRateUsb2, sizeof(s_bitRateUsb2) / sizeof(s_bitRateUsb2[0]));
  }
  
  void AddPacketType(HciPacketType packetType, bool isFromHost)
  {
    Add((uint8_t)ObjectIdHciPacketType);
    Add((uint8_t)(isFromHost ? packetType : packetType | PacketTypeFromController));
  }
  
  void AddPacketData(const uint8_t* const data, int size)
  {
    Add((uint8_t)ObjectIdHciPacketData);
    Add(data, size);
  }
};

uint8_t InjectionSink::s_bitRateUsb2[] = { 0x00, 0x1B, 0x37, 0x4B };

class Parser
{
public:
  Parser(InjectionSink sink) : m_sink(sink) {}
  
  void Parse(istream &input)
  {
    while(input)
    {
      // read timestamp
      Timestamp timestamp;
      
      input >> dec >> timestamp.Year;
      input.ignore();
      input >> dec >> timestamp.Month;
      input.ignore();
      input >> dec >> timestamp.Day;
      input.ignore();
      
      input >> dec >> timestamp.Hour;
      input.ignore();
      input >> dec >> timestamp.Minute;
      input.ignore();
      input >> dec >> timestamp.Second;
      
      // read direction
      char direction;      
      input >> ws >> direction;
      
      m_dump.Start(timestamp, direction == '<');
      
      // read hex numbers
      while(input && !m_dump.IsComplete())
      {
	int hexNumber;
	input >> hex >> hexNumber;	
	m_dump.Add((uint8_t)hexNumber);
      }      

      m_sink.Process(m_dump);
      //usleep(1);
    }
  }

private:
  HciDumpPacket m_dump;
  InjectionSink m_sink;
};

int main(int argc, char **argv)
{
  if(argc < 2)
  {
    cerr << "Usage: hciremotelog <address> [<port>]" << endl;
    return -1;
  }
    
  char *address = argv[1];
  const char *port;
  
  if(argc >= 3)
  {
    port = argv[2];
  }
  else
  {
    port = "24352";
  }
    
  SafeHandle socketHandle = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
   
  if(socketHandle < 0)
  {
    cerr << "Failed to create UDP socket" << endl;
    return -2;
  }
  
  sockaddr_in remoteAddr = {};
  remoteAddr.sin_family = AF_INET;
  
  if(inet_aton(address, &remoteAddr.sin_addr) <= 0)
  {
    cerr << "Invalid IP" << endl;
    return -3;
  }
  
  remoteAddr.sin_port = htons(atoi(port));
  
  clog << "Logging to " << address << ":" << port << endl; 
  
  InjectionSink sink = InjectionSink(socketHandle, remoteAddr);
  
  //fstream file;
  //file.open("/root/dump", ios_base::in);
    
  istream &input = cin; // file;
  string line = string();
  
  for(int i = 0; i < 2; ++i)
  {
    getline(input, line);  
    clog << line << endl;
  }
  
  Parser parser = Parser(sink);
  parser.Parse(input);
  
  return 0;
}
