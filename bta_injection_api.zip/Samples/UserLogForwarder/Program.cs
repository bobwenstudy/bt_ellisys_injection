﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using Ellisys.Injection;

namespace UserLogForwarder;

static class Program
{
	//
	// This sample uses the Ellisys live log injection API to send input lines as sniffer log messages.
	// If no filename argument is given, it reads from STDIN
	//
	public static void Main(string[] args)
	{
		// TO BE CONFIGURED:
		const string ServerIpAddress = "127.0.0.1";  // Use 127.0.0.1 when running in local computer
		const int ServerInjectionPort = 24352;
		var endPoint = new IPEndPoint(IPAddress.Parse(ServerIpAddress), ServerInjectionPort);

		using var buffer = new MemoryStream();
		using var writer = new BinaryWriter(buffer, Encoding.UTF8);
		using var sender = new UdpClient(0);
		using var reader = args.Length == 1 ? ReadFile(args[0]) : Console.In;

		while (true)
		{
			var line = reader.ReadLine();
			if (line == null) return;
			if (line.Length == 0) continue;

			buffer.SetLength(0);
			FormatMessage(writer, line);

			var messageData = buffer.ToArray();
			sender.Send(messageData, messageData.Length, endPoint);
		}
	}

	private static StreamReader ReadFile(string path) => new(File.OpenRead(path));

	private static void FormatMessage(BinaryWriter writer, string text)
	{
		const ushort LogInjectionServiceId = 0x0001;
		const byte LogInjectionServiceVersion = 0x01;

		writer.WriteServiceId(LogInjectionServiceId, LogInjectionServiceVersion);
		writer.WriteDateTimeMs(DateTime.UtcNow);
		writer.WriteLogField(text);
		writer.Flush();
	}
}
