﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Ellisys.Injection;

namespace UserLogClient;

static class Program
{
	//
	// This sample uses the Ellisys live log injection API to push a test message repeatedly.
	//
	public static void Main()
	{
		// TO BE CONFIGURED:
		const string ServerIpAddress = "127.0.0.1";  // Use 127.0.0.1 when running in local computer
		const int ServerInjectionPort = 24352;
		var endPoint = new IPEndPoint(IPAddress.Parse(ServerIpAddress), ServerInjectionPort);

		using var buffer = new MemoryStream();
		using var writer = new BinaryWriter(buffer, Encoding.UTF8);
		using var sender = new UdpClient(0);

		for (var i = 0; i < 100; ++i)
		{
			buffer.SetLength(0);
			WriteTestMessage(writer);

			var testMessage = buffer.ToArray();
			sender.Send(testMessage, testMessage.Length, endPoint);

			Thread.Sleep(300); // throttle: UDP is dropped at receiver when sent too fast
		}
	}

	private static void WriteTestMessage(BinaryWriter writer)
	{
		const ushort LogInjectionServiceId = 0x0001;
		const byte LogInjectionServiceVersion = 0x01;

		writer.WriteServiceId(LogInjectionServiceId, LogInjectionServiceVersion);
		writer.WriteDateTimeMs(DateTime.UtcNow);

		writer.WriteLogField("Test", "Message");

		writer.WriteGroupStart();
		writer.WriteLogField("Item 1", "Value 1");
		writer.WriteLogField("Item 2", "Suspicious Value 2", Severity.Warning);
		writer.WriteLogField("Item 3", "Error Value", Severity.Error);
		writer.WriteGroupEnd();

		writer.Flush();
	}
}
